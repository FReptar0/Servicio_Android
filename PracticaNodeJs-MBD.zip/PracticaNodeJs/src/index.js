const { app } = require ('./config/express');

const main = () =>{
    try{
        app.listen(app.get('port'));
        console.log(`Server is running in http://localhost:${app.get('port')}/`);
    }catch(e){
        console.log(e);
    }
}

main();