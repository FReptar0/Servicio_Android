const express = require('express');
require('dotenv').config();
const cors = new require('cors');
const {personalRouter} = require("../modules/controller/personal/personal.controller");
const {userRouter} = require("../modules/controller/user/user.controller");
const { } = require('../modules/controller/routes')
const app = express();

app.set("port", process.env.PORT || 3000);
app.use(cors({origins:"*"}));
app.use(express.json({limit: '50mb'}));

app.get('/', (req, res) => {
    res.send("Hola bienvenido a la APP de 4°D");
});

app.use('/api/personal', personalRouter)
app.use('/api/user', userRouter)

module.exports = {
    app
}