const mysql = require('mysql');
require('dotenv').config();

const client = mysql.createPool({
    connectionLimit:5,
    host:process.env.DB_HOST,
    user:process.env.DB_USER,
    password:process.env.DB_PASSWORD,
    database:process.env.DB_DATABASE,
    port:process.env.DB_PORT,
    multipleStatements: true
})

console.log('process.env.DB_HOST: ', process.env.DB_HOST)
console.log('process.env.DB_USER: ', process.env.DB_USER)
console.log('process.env.DB_PASSWORD: ', process.env.DB_PASSWORD)
console.log('process.env.DB_DATABASE: ', process.env.DB_DATABASE)
console.log('process.env.DB_PORT: ', process.env.DB_PORT)

const query = (sql, params)=>{
    return new Promise((resolve, reject)=>{
        client.getConnection((err, conn)=>{
            if(err) reject(err);
            conn.query(sql, params, (err, rows)=>{
                if(err) reject(err);
                conn.release();
                resolve(rows);
            });
        });
    });
};

module.exports = {
    query
}