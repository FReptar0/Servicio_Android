const { Response, Router} = require ('express');
const { validateError } = require('../../../utils/functions');
const { findAll, findByID, save, update, remove } = require('./user.gateway');

const getAll = async (req, res = Response) => {
    try {
        const user = await findAll();
        res.status(200).json({user});
    } catch (error) {
        console.log(erorr);
        const message = validateError(error);
        res.status(400).json({message});
    }
};

const getByID = async (req, res = Response) => {
    try {
        const { id } = req.params;
        const user = await findByID(id);
        res.status(200).json(user);
    } catch (error) {
      console.log(error);
      const message = validateError(error);
      res.status(400).json({message});
    }
};

const insertU = async (req, res = Response) => {
    try{
        const { email, password, role, personal_id} = req.body;
        const user = await save ({email, password, role, personal_id});
        res.status(200).json(user);
    } catch (error) {
        console.log(error);
        const message = validateError(error);
        res.status(400).json({message});
    }
};

const updateU = async (req, res = Response) => {
    try{
        const { id } = req.params;
        const { email, password, role, status, personal_id} = req.body;
        const user = await update({ email, password, role, status, personal_id}, id);
        res.status(200).json(user);
    } catch (error) {
        console.log(error);
        const message = validateError(error);
        res.status(400).json({message});
    }
};

const removeP = async (req, res = Response) => {
    try{
        const { id } = req.params;
        const user = await remove(id);
        res.status(200).json(user);
    } catch (error) {
        console.log(error);
        const message = validateError(error);
        res.status(400).json({message});
    }
};

const userRouter = Router();

userRouter.get('/', getAll);
userRouter.get('/:id', getByID);
userRouter.post('/', insertU);
userRouter.put('/:id', updateU);
userRouter.delete('/:id', removeP)


module.exports = {
    userRouter
}