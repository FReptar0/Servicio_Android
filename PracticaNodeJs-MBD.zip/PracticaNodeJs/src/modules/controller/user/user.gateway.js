const { query } = require('../../../utils/mysql');
const { process_params } = require('express/lib/router');

const findAll = async () => {
    const sql = `SELECT * FROM users ORDER BY id`;
    return await query(sql, [])
};

const findByID = async (id) => {
    if (!id) throw Error ('Missing fields');
    if (Number.isNaN(id)) throw Error ('Wrong Type');
    const sql = `SELECT * FROM users WHERE id=?`;
    return await query (sql, [id]);
};

const save = async (user) => {
    if (!user.email ||
        !user.password ||
        !user.role ||
        !user.personal_id) throw Error('Missing fields')
   if ((user.role.toLowerCase() !== "admin") && (user.role.toLowerCase() !== "user")) throw ('Only Admin or User');
    const sql = `INSERT INTO users (email, password, role, status, personal_id) VALUES (?,?,?,1,?)`;
    const { insertId } = await  query(sql, [
        user.email,
        user.password,
        user.role,
        user.personal_id
    ]);
    return { id:insertId, status:1, ...user};
};

const update = async (user, id) => {
    if (!id) throw Error ('Missing field');
    if (Number.isNaN(id)) throw Error ('Wrong Type');
    if (!user.email ||
        !user.password ||
        !user.role ||
        !user.status && user.status !=0 ||
        !user.personal_id) throw Error ('Missing field');
    if (user.status != 0 && user.status != 1) throw Error ('Only 0 or 1')
    const sql = `UPDATE users SET email=?, password=?, role=?, status=?, personal_id=? WHERE id=?`
    await query (sql, [
        user.email,
        user.password,
        user.role,
        user.status,
        user.personal_id,
        id
    ]);
    return {id:id, ...user}
};

const remove = async (id) => {
    if (!id) throw Error ('Missing Field');
    if (Number.isNaN(id)) throw Error ('Wrong Type');
    const sql = `DELETE FROM users WHERE id=?`;
    await query(sql, [id]);
    return {idDeleted:id};
};


module.exports = {
    findAll,
    findByID,
    save,
    update,
    remove
}
