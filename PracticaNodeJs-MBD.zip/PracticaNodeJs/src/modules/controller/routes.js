const { personalRouter } = require('./personal/personal.controller');
const { userRouter } = require('./user/user.controller');

module.exports = {
    personalRouter,
    userRouter
}