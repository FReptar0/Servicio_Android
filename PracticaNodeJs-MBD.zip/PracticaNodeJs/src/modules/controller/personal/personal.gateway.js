const { query } = require ('../../../utils/mysql');
const {process_params} = require('express/lib/router');

const findAll = async() => {
    const sql = `SELECT pe.*, po.description
    FROM personal pe JOIN position po
    on po.id=pe.position_id ORDER BY pe.id`;
    return await query(sql, []);
};

const findByID = async (id) => {
    if (!id) throw Error ('Missing fields');
    if (Number.isNaN(id)) throw Error('Wrong Type');
    const sql = `SELECT pe.*, po.description
    FROM personal pe JOIN position po
    ON po.id=pe.position_id WHERE pe.id=?`;
    return await query(sql, [id]);
}

const save = async (person) => {
    if (!person.name ||
        !person.lastname ||
        !person.birthday ||
        !person.salary ||
        !person.position.id) throw Error('Missing Field');
    const sql = `INSERT INTO personal (name, lastname, birthday, salary, position_id) VALUES (?,?,?,?,?)`;
    const { insertId } = await query( sql, [
        person.name,
        person.lastname,
        person.birthday,
        person.salary,
        person.position.id
    ]);
    return { ...person, id:insertId };
}

const update = async (person, id) => {
    if (!id ) throw Error ('Missing fields');
    if (Number.isNaN(id)) throw Error ('Wrong Type');
    if (!person.name ||
        !person.lastname ||
        !person.birthday ||
        !person.salary) throw Error('Missing Field');
    const sql = `UPDATE personal SET name=?, lastname=?, birthday=?, salary=? WHERE id=?`;
    await query(sql, [
        person.name,
        person.lastname,
        person.birthday,
        person.salary,
        id
    ]);
    return { ...person, id:id}
};

const remove = async (id) => {
    if (!id) throw Error ('Missing fields');
    if (Number.isNaN(id)) throw Error ('Wrong Type');
    const sql = `DELETE FROM personal WHERE id=?`;
    await query(sql, [id]);
    return {idDeleted:id};
};

const prueba = async (user, id) => {
    if (!id) throw Error ('Missig field');
    if (Number.isNaN(id)) throw Error ('Wrong Type');
    if (!user.salary) throw Error ('Missing field');
    const sql = `UPDATE personal SET salary=salary+? WHERE id=?`;
    await query (sql, [user.salary, id]);
};

module.exports = {
    findAll,
    findByID,
    save,
    update,
    remove,
    prueba
}