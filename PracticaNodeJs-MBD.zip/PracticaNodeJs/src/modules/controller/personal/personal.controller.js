const { Response, Router } = require ('express');
const { validateError } = require('../../../utils/functions');
const { findAll, findByID, save, update, remove, prueba} = require('./personal.gateway');

const getAll = async (req, res=Response) => {
    try {
        const personal = await findAll();
        res.status(200).json({personal});
    } catch (error) {
        console.log(error);
        const message = validateError(error);
        res.status(400).json({message});

    }
};

const  getById = async (req, res = Response) => {
    try {
        const { id } = req.params;
        const person = await findByID(id);
        res.status(200).json(person);
    } catch (error) {
        console.log(error);
        const message = validateError(error);
        res.status(400).json({message});
    }
};

const insert = async (req, res = Response) => {
    try {
        const { name, lastname, birthday, salary, position } = req.body;
        const person = await save ({ name, lastname, birthday, salary, position });
        res.status(200).json(person);
    } catch (error) {
        console.log(error);
        const message = validateError(error);
        res.status(400).json({message});
    }
};

const updateP = async (req, res = Response) => {
    try {
        const { id } = req.params;
        const { name, lastname, birthday, salary } = req.body;
        const person = await update({ name, lastname, birthday, salary}, id);
        res.status(200).json(person);
    } catch (error) {
        console.log(error);
        const message = validateError(error);
        res.status(400).json({message});
    }
};

const updateS = async (req, res = Response) => {
    try{
        const { id } = req.params;
        const { salary } = req.body;
        const user = await prueba({salary}, id);
        const data = await findByID(id);
        res.status(200).json(data);
    } catch (error) {
        console.log(error);
        const message = validateError(error);
        res.status(400).json({message});
    }
};

const removeP = async (req, res = Response) => {
    try {
        const { id } = req.params;
        const person = await remove(id);
        res.status(200).json(person);
    } catch (error) {
        console.log(error);
        const message = validateError(error);
        res.status(400).json({message});
    }
};

const  personalRouter = Router();

personalRouter.get('/', getAll);
personalRouter.get('/:id', getById);
personalRouter.post('/', insert);
personalRouter.put('/:id', updateP);
personalRouter.put('/prueba/:id', updateS);
personalRouter.delete('/:id', removeP);


module.exports = {
    personalRouter
}
